const PREFIX = "http://192.168.9.102/";
const PATTERN = "http://192.168.9.102/*";

const isTarget = (url) => typeof url === "string" && url.startsWith(PREFIX);

async function enforceSingleTab(tab) {
  const url = tab.url || tab.pendingUrl;
  if (!isTarget(url)) return;

  // Tìm các tab khác đang mở web nội bộ
  const all = await chrome.tabs.query({ url: PATTERN });
  const others = all
    .filter((t) => t.id !== tab.id)
    .sort((a, b) => a.id - b.id);
  if (others.length === 0) return; // đây là tab đầu tiên

  const first = others[0];
  try {
    await chrome.windows.update(first.windowId, { focused: true });
    await chrome.tabs.update(first.id, { active: true });
  } catch (e) {}
  try {
    await chrome.tabs.remove(tab.id);
  } catch (e) {}
}

chrome.tabs.onCreated.addListener((tab) => enforceSingleTab(tab));

chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
  if (changeInfo.url || changeInfo.status === "loading") enforceSingleTab(tab);
});
