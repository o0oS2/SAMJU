// Auto Mes OQC V2 - content script (chuyển thể từ userscript "Barcode Auto Re-paste" v2.0)
// Nhận diện 3 ô theo TÊN NHÃN hiển thị (ổn định) thay vì theo id (do MUI tự sinh, dễ đổi
// khi bố cục trang thay đổi -> hay gây lỗi "mở web không chạy"): ô "Mã Lot bán thành phẩm"
// (ghi mã), ô "Tem bản vẽ" (lot id), ô "Mã Lot APP" (dán). Ghi mã khi bắn Enter vào 2 danh
// sách song song: (1) Phần 1 - dán tuần tự vào ô "Mã Lot APP", tự xóa sau khi dán hết; chỉ
// tự điền 11 ký tự đầu của lot id vào ô "Tem bản vẽ" khi ô đó đang TRỐNG, và chỉ dán các mã
// có 11 ký tự đầu trùng với nội dung hiện tại của ô "Tem bản vẽ" - mã không trùng sẽ bị bỏ
// qua; (2) Backup - lưu lại mọi mã mới, mã trùng với mã đã có trong Backup sẽ bị bỏ qua; nút
// dán tự động ở Backup chỉ dán các mã có 11 ký tự đầu trùng với ô "Tem bản vẽ", không tự xóa
// sau khi dán, chỉ tự mất từng mã sau đúng 1h. Chỉ cho dán khi đang chọn đúng ô "Mã Lot APP".
// Panel tự ẩn/hiện theo ô đang focus.

(async function () {
  'use strict';

  const STORAGE_KEY = 'bar_auto_repaste_list_v1';
  const BACKUP_KEY = 'bar_auto_repaste_backup_v1';
  const SETTINGS_KEY = 'bar_auto_repaste_settings_v1';
  const ACTIVITY_KEY = 'bar_auto_repaste_activity_v1';
  const ONE_HOUR_MS = 60 * 60 * 1000;

  const DELAY_MS = 500;
  const BACKUP_SWEEP_MS = 30 * 1000; // dò và xóa các mã backup đã đủ 1h mỗi 30s
  const COUNTDOWN_TICK_MS = 1000; // cập nhật đồng hồ đếm ngược mỗi 1s

  // Nhận diện 3 ô theo TÊN NHÃN hiển thị cạnh ô, thay vì theo id.
  // Lý do: id kiểu "mui-98" là do MUI tự đánh số theo thứ tự component render ra,
  // có thể đổi khác giữa các lần tải trang/điều hướng -> id cũ không còn đúng nữa,
  // script tìm không thấy ô và không chạy. Tên nhãn thì cố định, không đổi.
  const SCAN_LABEL_TEXT = 'Mã Lot bán thành phẩm'; // ô bắn barcode để ghi mã
  const LOTID_LABEL_TEXT = 'Tem bản vẽ'; // ô nhận 11 ký tự đầu của lot id
  const PASTE_LABEL_TEXT = 'Mã Lot APP'; // ô duy nhất được phép dán vào
  const LOTID_PREFIX_LEN = 11;

  // Chỉ coi là thành công khi web hiện thông báo (toast) có chữ này.
  const SUCCESS_TEXT = 'thành công';
  // Toast LỖI của web: nhận ra ngay (không phải chờ hết thời gian) -> mã đó tính là lỗi tức thì.
  // Thêm chữ toast lỗi khác vào đây (viết thường) nếu web còn báo lỗi bằng chữ khác.
  const ERROR_TEXTS = ['mã lot đã nhận'];
  const TOAST_TIMEOUT_MS = 2000; // chờ tối đa 2s để thấy toast "Thành công" (server nội bộ rất nhanh)
  const TOAST_SETTLE_MS = 300; // chỉ dùng sau khi tự điền ô "Tem bản vẽ" (cho toast của ô đó qua hẳn)
  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

  // ---------- Lưu trữ: dùng chrome.storage.local thay cho GM_getValue/GM_setValue ----------
  const stored = await chrome.storage.local.get([
    STORAGE_KEY,
    BACKUP_KEY,
    SETTINGS_KEY,
    ACTIVITY_KEY,
  ]);

  let codes = stored[STORAGE_KEY] || []; // Phần 1: [{value, pasted:boolean}] - tự xóa sau khi dán hết
  let backupCodes = stored[BACKUP_KEY] || []; // Phần 2: [{value, ts, pasted:boolean}] - tự xóa sau 1h/mã
  let settings = stored[SETTINGS_KEY] || { hotkey: 'F9' };
  let lastActivity = stored[ACTIVITY_KEY] || Date.now();

  function save() {
    chrome.storage.local.set({
      [STORAGE_KEY]: codes,
      [BACKUP_KEY]: backupCodes,
      [SETTINGS_KEY]: settings,
    });
  }

  function touchActivity() {
    lastActivity = Date.now();
    chrome.storage.local.set({ [ACTIVITY_KEY]: lastActivity });
  }

  // ---------- Theo dõi toast "Thành công" của web ----------
  // Mỗi lần web hiện 1 toast chứa chữ "Thành công" -> toastCount tăng 1 và đánh thức
  // những chỗ đang chờ (ghi mã khi bắn / dán từng mã).
  let toastCount = 0; // tổng số toast thành công đã thấy
  let errorCount = 0; // tổng số toast lỗi đã thấy
  let lastErrorText = ''; // chữ của toast lỗi gần nhất
  const toastWaiters = []; // [{baseOk, baseErr, resolve, timer}]
  const pendingScans = []; // mã vừa bắn, đang chờ toast: [{value, timer}]

  function wakeWaiters() {
    for (let i = toastWaiters.length - 1; i >= 0; i--) {
      const w = toastWaiters[i];
      let result = null;
      if (toastCount > w.baseOk) result = true;
      else if (errorCount > w.baseErr) result = false;
      if (result !== null) {
        clearTimeout(w.timer);
        toastWaiters.splice(i, 1);
        w.resolve(result);
      }
    }
  }

  // n = số toast "Thành công" mới xuất hiện cùng lúc (có thể nhiều toast chồng nhau)
  function onSuccessToast(n) {
    toastCount += n;
    wakeWaiters();
    // mỗi toast ứng với 1 mã bắn (theo thứ tự bắn)
    for (let k = 0; k < n; k++) {
      const p = pendingScans.shift();
      if (!p) break;
      clearTimeout(p.timer);
      commitScan(p.value);
    }
  }

  function onErrorToast(text) {
    errorCount++;
    lastErrorText = text;
    wakeWaiters();
    // mỗi toast ứng với đúng 1 mã bắn (theo thứ tự bắn)
    const p = pendingScans.shift();
    if (p) {
      clearTimeout(p.timer);
      flashPanel('#f44336', `Web báo "${text}", KHÔNG ghi: ${p.value}`);
    }
  }

  function waitForSuccessToast(baseOk, baseErr) {
    return new Promise((resolve) => {
      if (toastCount > baseOk) return resolve(true);
      if (errorCount > baseErr) return resolve(false);
      const w = { baseOk, baseErr, resolve };
      w.timer = setTimeout(() => {
        const i = toastWaiters.indexOf(w);
        if (i >= 0) toastWaiters.splice(i, 1);
        resolve(false);
      }, TOAST_TIMEOUT_MS);
      toastWaiters.push(w);
    });
  }

  // Màu nền đỏ? (toast lỗi của web có nền đỏ, toast thành công có nền xanh)
  function isRedBg(el) {
    try {
      const m = getComputedStyle(el).backgroundColor.match(/rgba?\(([^)]+)\)/);
      if (!m) return false;
      const [r, g, b, a] = m[1].split(',').map((x) => parseFloat(x));
      if (a !== undefined && !isNaN(a) && a < 0.5) return false;
      return r >= 170 && g <= 130 && b <= 130;
    } catch (e) {
      return false;
    }
  }

  // Toast lỗi = bất kỳ toast nào hiện ra mà KHÔNG phải "Thành công". Nhận ra bằng 1 trong 3 cách:
  //  (1) chữ nằm trong ERROR_TEXTS; (2) phần tử là toast/thông báo theo class hoặc role;
  //  (3) phần tử (hoặc con của nó) có nền đỏ. Trả về chữ của toast, hoặc '' nếu không phải toast lỗi.
  function errorTextIn(el) {
    const raw = (el.textContent || '').replace(/\s+/g, ' ').trim();
    if (raw.length < 2 || raw.length > 100) return '';
    const low = raw.toLowerCase();
    if (ERROR_TEXTS.some((t) => low.includes(t))) return raw;
    const cls = (el.className && el.className.toString ? el.className.toString() : '').toLowerCase();
    const role = (el.getAttribute && el.getAttribute('role')) || '';
    if (/toast|snack|notif/.test(cls) || role === 'alert') return raw;
    if (isRedBg(el)) return raw;
    const kids = el.querySelectorAll ? el.querySelectorAll('*') : [];
    for (let i = 0; i < kids.length && i < 30; i++) {
      if (isRedBg(kids[i])) return raw;
    }
    return '';
  }

  // Đếm số lần chữ "Thành công" xuất hiện trong phần tử vừa được thêm vào trang.
  // Chỉ tính khi phần tử đó CHỈ gồm các chữ "Thành công" (+ dấu x đóng), để không đếm nhầm
  // khối lớn như cả bảng/trang tình cờ chứa chữ này. Nhờ đếm theo số lần xuất hiện nên
  // nhiều toast hiện chồng nhau cùng lúc vẫn đếm đủ, không bị gộp thành 1.
  function countSuccessIn(el) {
    const text = (el.textContent || '').replace(/\s+/g, ' ').trim().toLowerCase();
    if (!text || !text.includes(SUCCESS_TEXT)) return 0;
    const parts = text.split(SUCCESS_TEXT);
    const rest = parts.join('').replace(/[×✕✖xX\s]/g, '');
    if (rest.length > 0) return 0;
    return parts.length - 1;
  }

  // Web dùng thư viện react-toastify: mỗi toast là <div class="Toastify__toast Toastify__toast--success|error">.
  // Nhận loại toast thẳng theo class này (chắc chắn nhất); chỉ khi không thấy class mới quay về
  // cách đoán theo chữ/màu nền như bên trên.
  const seenToastRoots = new WeakSet();

  function handleAddedNode(el) {
    const roots = [];
    const up = el.closest ? el.closest('.Toastify__toast') : null;
    if (up) roots.push(up);
    if (el.querySelectorAll) roots.push(...el.querySelectorAll('.Toastify__toast'));

    if (roots.length > 0) {
      for (const root of roots) {
        if (seenToastRoots.has(root)) continue;
        seenToastRoots.add(root);
        const cls = root.className.toString();
        const text = (root.textContent || '').replace(/\s+/g, ' ').trim();
        if (/Toastify__toast--success/.test(cls)) {
          console.debug('[Auto Mes] toast thành công:', text);
          onSuccessToast(1);
        } else if (/Toastify__toast--(error|warning)/.test(cls)) {
          console.debug('[Auto Mes] toast lỗi:', text);
          onErrorToast(text || 'Lỗi');
        } else {
          // toast không có class loại quen thuộc -> đoán theo chữ / màu nền
          const n = countSuccessIn(root);
          if (n > 0) {
            console.debug('[Auto Mes] toast thành công (theo chữ):', text);
            onSuccessToast(n);
          } else {
            const err = errorTextIn(root);
            if (err) {
              console.debug('[Auto Mes] toast lỗi (theo chữ/màu):', err);
              onErrorToast(err);
            } else {
              console.debug('[Auto Mes] toast không nhận ra:', cls, '|', text);
            }
          }
        }
      }
      return;
    }
    if (el.closest && el.closest('.Toastify')) return; // phần con của toast (icon, thanh tiến trình...)

    // Dự phòng khi trang không dùng react-toastify: đoán theo chữ / màu nền
    const n = countSuccessIn(el);
    if (n > 0) {
      console.debug('[Auto Mes] toast thành công x' + n);
      onSuccessToast(n);
      return;
    }
    const err = errorTextIn(el);
    if (err) {
      console.debug('[Auto Mes] toast lỗi:', err);
      onErrorToast(err);
    }
  }

  const toastObserver = new MutationObserver((mutations) => {
    for (const m of mutations) {
      for (const node of m.addedNodes) {
        const el = node.nodeType === 1 ? node : node.parentElement;
        if (!el || (typeof panel !== 'undefined' && panel.contains(el))) continue;
        handleAddedNode(el);
      }
    }
  });
  toastObserver.observe(document.documentElement, { childList: true, subtree: true });

  // ---------- Helper: đặt giá trị input kiểu tương thích React/Vue ----------
  function setNativeValue(element, value) {
    const proto = Object.getPrototypeOf(element);
    const descriptor = Object.getOwnPropertyDescriptor(proto, 'value');
    if (descriptor && descriptor.set) {
      descriptor.set.call(element, value);
    } else {
      element.value = value;
    }
    element.dispatchEvent(new Event('input', { bubbles: true }));
    element.dispatchEvent(new Event('change', { bubbles: true }));
  }

  function fireEnter(element) {
    ['keydown', 'keypress', 'keyup'].forEach((type) => {
      const ev = new KeyboardEvent(type, {
        key: 'Enter',
        code: 'Enter',
        bubbles: true,
        cancelable: true,
      });
      // Chrome không cho set keyCode/which qua constructor (luôn ra 0),
      // nhiều web cũ kiểm tra e.keyCode===13 nên phải ép thủ công.
      try {
        Object.defineProperty(ev, 'keyCode', { get: () => 13 });
        Object.defineProperty(ev, 'which', { get: () => 13 });
      } catch (err) {
        /* ignore nếu trình duyệt không cho ghi đè */
      }
      element.dispatchEvent(ev);
    });
  }

  function isEditable(el) {
    if (!el) return false;
    const tag = el.tagName ? el.tagName.toLowerCase() : '';
    return tag === 'input' || tag === 'textarea' || el.isContentEditable;
  }

  function normalizeText(s) {
    return (s || '').replace(/\s+/g, ' ').trim();
  }

  // Tìm ô input theo TÊN NHÃN hiển thị (label) thay vì theo id, vì id do MUI tự sinh
  // và có thể đổi khác giữa các lần tải trang. Luôn dò lại DOM mới nhất mỗi lần gọi
  // (không cache) để không bao giờ bị "dính" vào một id/element cũ đã mất hiệu lực.
  function findFieldByLabel(labelText) {
    const labels = Array.from(document.querySelectorAll('label')).filter(
      (lbl) => normalizeText(lbl.textContent) === labelText
    );
    if (labels.length === 0) return null;

    // Trang có thể có nhiều ô trùng tên nhãn (VD: 1 ô lọc/tìm kiếm khác đặt tên y hệt
    // ô bắn mã). 3 ô mà tool này cần luôn là dạng "outlined" (ô có khung viền), khác
    // với ô lọc dạng "standard" (chỉ gạch chân) -> ưu tiên chọn label dạng outlined
    // trước để tránh bắt nhầm sang ô khác trùng tên.
    const outlined = labels.find((lbl) => lbl.classList.contains('MuiInputLabel-outlined'));
    const chosen = outlined || labels[0];

    const forId = chosen.getAttribute('for');
    if (forId) {
      const el = document.getElementById(forId);
      if (el) return el;
    }
    // Dự phòng: nếu label không có "for" hợp lệ, tìm input/textarea nằm trong
    // cùng khối MuiFormControl chứa label này.
    const wrap = chosen.closest('.MuiFormControl-root') || chosen.parentElement;
    if (wrap) {
      const inp = wrap.querySelector('input, textarea');
      if (inp) return inp;
    }
    return null;
  }

  function getScanInput() {
    return findFieldByLabel(SCAN_LABEL_TEXT);
  }
  function getLotIdInput() {
    return findFieldByLabel(LOTID_LABEL_TEXT);
  }
  function getPasteInput() {
    return findFieldByLabel(PASTE_LABEL_TEXT);
  }

  // Ghi nhớ ô input cuối cùng được focus, vì bấm nút trong panel sẽ làm ô input
  // bị mất focus (document.activeElement đổi sang cái nút) -> phải nhớ lại từ trước.
  let lastEditable = null;
  document.addEventListener(
    'focusin',
    (e) => {
      if (isEditable(e.target) && !panel.contains(e.target)) {
        lastEditable = e.target;
        updateTargetLabel();
      }
    },
    true
  );

  // ---------- Tự ẩn/hiện panel theo ô đang focus ----------
  // Focus vào ô "Mã Lot bán thành phẩm" (ghi mã) -> hiện panel ở chế độ "scan":
  //   chỉ hiện số mã đã lưu, ẩn nút Dán (vì lúc này chưa được phép dán).
  // Focus vào ô "Mã Lot APP" (dán) -> hiện panel đầy đủ, có nút Dán như bình thường.
  // Focus ra chỗ khác -> ẩn hẳn panel. Nếu đã tắt tay bằng nút X thì luôn ẩn tới khi F5.
  document.addEventListener(
    'focusin',
    (e) => {
      const el = e.target;
      if (!el || panel.contains(el)) return; // thao tác trong panel không làm ẩn panel
      if (el === getPasteInput()) {
        showPanel('full');
      } else if (el === getScanInput()) {
        showPanel('scan');
      } else {
        hidePanel();
      }
    },
    true
  );

  function showPanel(mode) {
    panel.style.display = 'block';
    setPanelMode(mode);
  }
  function hidePanel() {
    panel.style.display = 'none';
  }

  // "full": hiện đầy đủ (nút Dán + nút thu gọn/mở rộng) - dùng khi đang ở ô #mui-98.
  // "scan": chỉ hiện số mã đã lưu, ẩn nút Dán và thu nhỏ panel vừa khít nội dung - dùng khi
  // đang ghi mã ở ô #mui-5, vì lúc này không được phép dán (pasteValueToTarget sẽ tự chặn,
  // nhưng ẩn nút đi cho gọn giao diện và đỡ bấm nhầm).
  function setPanelMode(mode) {
    const autoBtn = $('#mx2-auto-btn');
    if (!autoBtn) return; // panel UI chưa dựng xong
    if (mode === 'scan') {
      autoBtn.style.display = 'none';
      if (!minimized) {
        minimized = true;
      }
      applyMinimized();
      // Ép panel thu nhỏ khít theo nội dung (chỉ còn số đếm + nút thu gọn),
      // thay vì giữ nguyên bề rộng cố định 150px như lúc còn nút Dán.
      panel.style.width = 'fit-content';
      panel.style.minWidth = '0';
    } else {
      autoBtn.style.display = '';
      panel.style.minWidth = '';
      applyMinimized(); // trả lại bề rộng cố định (150px/300px) theo trạng thái thu gọn/mở rộng
    }
  }

  function describeEl(el) {
    if (!el) return '(chưa chọn ô nào)';
    const name = el.name || el.id || el.placeholder || el.getAttribute('aria-label');
    return name ? `<${el.tagName.toLowerCase()}> "${name}"` : `<${el.tagName.toLowerCase()}>`;
  }
  function updateTargetLabel() {
    const lbl = document.getElementById('mx2-target-label');
    if (lbl) lbl.textContent = describeEl(getTargetEl());
  }

  function getTargetEl() {
    if (lastEditable && document.contains(lastEditable)) return lastEditable;
    if (isEditable(document.activeElement) && !panel.contains(document.activeElement)) {
      return document.activeElement;
    }
    return null;
  }

// ---------- GIAI ĐOẠN 1: ghi mã khi bắn Enter (chỉ ghi mã từ 20 ký tự trở lên) ----------
document.addEventListener(
  'keydown',
  (e) => {
    if (e.key !== 'Enter') return;
    const el = document.activeElement;
    if (!isEditable(el)) return;

    // Kiểm tra xem có đang bắn ở đúng ô "Mã Lot bán thành phẩm" hay không
    if (el !== getScanInput()) return;

    const val = (el.isContentEditable ? el.innerText : el.value || '').trim();
    if (!val) return;

    // Kiểm tra độ dài mã: dưới 20 ký tự thì bỏ qua không ghi
    if (val.length < 20) {
      flashPanel('#f44336', `Mã ngắn hơn 20 ký tự (${val.length} kt), bỏ qua`);
      return;
    }

    const exists = backupCodes.some((c) => c.value === val) || pendingScans.some((p) => p.value === val);
    if (exists) {
      flashPanel('#ff9800', `Mã "${val}" đã có trong Backup, bỏ qua trùng`);
      return;
    }
    // Chưa ghi ngay: đợi web báo "Thành công" rồi mới ghi (xem commitScan).
    const p = { value: val };
    p.timer = setTimeout(() => {
      const i = pendingScans.indexOf(p);
      if (i >= 0) pendingScans.splice(i, 1);
      flashPanel('#f44336', `Không thấy toast nào báo kết quả (thành công ${toastCount}, lỗi ${errorCount} từ lúc mở trang), KHÔNG ghi: ${val}`);
    }, TOAST_TIMEOUT_MS);
    pendingScans.push(p);
    flashPanel('#3d6f96', `Đang chờ web báo thành công: ${val}`);
  },
  true
);

  function commitScan(val) {
    if (backupCodes.some((c) => c.value === val)) return;
    codes.push({ value: val, pasted: false });
    backupCodes.push({ value: val, ts: Date.now(), pasted: false });
    save();
    touchActivity();
    renderList();
    renderBackup();
    flashPanel('#4caf50', `Đã ghi: ${val}`);
  }

  // ---------- Helper dùng chung: dán 1 giá trị cụ thể vào ô đang focus ----------
  // Bắt buộc ô đang chọn phải đúng là ô "Mã Lot APP", nếu không sẽ báo lỗi và không dán.
  function pasteValueToTarget(value) {
    const target = getTargetEl();
    if (!target) {
      flashPanel('#f44336', `Hãy click vào ô "${PASTE_LABEL_TEXT}" trước!`);
      return false;
    }
    if (target !== getPasteInput()) {
      flashPanel('#f44336', `Chỉ được dán vào ô "${PASTE_LABEL_TEXT}"! Đang chọn ô khác.`);
      return false;
    }
    try {
      if (target.isContentEditable) {
        target.innerText = value;
        target.dispatchEvent(new Event('input', { bubbles: true }));
      } else {
        setNativeValue(target, value);
      }
      fireEnter(target);
      target.focus();
    } catch (err) {
      flashPanel('#f44336', 'Lỗi khi dán, đã dừng: ' + err.message);
      return false;
    }
    return true;
  }

  // Dán trực tiếp 1 giá trị vào 1 phần tử cụ thể, không qua kiểm tra focus (dùng cho ô "Tem bản vẽ").
  function pasteValueToElement(el, value) {
    if (!el) return false;
    try {
      if (el.isContentEditable) {
        el.innerText = value;
        el.dispatchEvent(new Event('input', { bubbles: true }));
      } else {
        setNativeValue(el, value);
      }
      fireEnter(el);
    } catch (err) {
      return false;
    }
    return true;
  }

  // Dán 1 mã rồi chờ web báo "Thành công". Trả về true chỉ khi thấy toast.
  async function pasteAndConfirm(value) {
    const baseOk = toastCount;
    const baseErr = errorCount;
    if (!pasteValueToTarget(value)) return false;
    return await waitForSuccessToast(baseOk, baseErr);
  }

  // ---------- GIAI ĐOẠN 2: dán tuần tự từ Phần 1 (tự xóa sau khi dán hết - như cũ) ----------
  let pasteBusy = false;
  // Trả về 'ok' (dán + thành công), 'fail' (dán nhưng web không báo thành công -> bỏ qua
  // mã đó, chạy tiếp mã sau) hoặc 'stop' (không dán được vì lý do khác, dừng hẳn).
  // skip: tập mã đã lỗi trong lượt chạy này (null khi dán 1 mã bằng phím tắt).
  async function pasteNext(skip) {
    if (pasteBusy) return 'stop';
    pasteBusy = true;
    try {
      return await pasteNextInner(skip);
    } finally {
      pasteBusy = false;
    }
  }

  async function pasteNextInner(skip) {
    const target = getTargetEl();
    if (!target) {
      flashPanel('#f44336', `Hãy click vào ô "${PASTE_LABEL_TEXT}" trước!`);
      return 'stop';
    }
    if (target !== getPasteInput()) {
      flashPanel('#f44336', `Chỉ được dán vào ô "${PASTE_LABEL_TEXT}"! Đang chọn ô khác.`);
      return 'stop';
    }

    const remaining = codes.filter((c) => !c.pasted && !(skip && skip.has(c)));
    if (remaining.length === 0) {
      flashPanel('#f44336', 'Hết mã để dán');
      return 'stop';
    }

    // Chỉ tự điền 11 ký tự đầu của lot id vào ô "Tem bản vẽ" khi ô đó đang TRỐNG.
    // Nếu ô đó đã có dữ liệu thì giữ nguyên, không ghi đè.
    if (!getLotIdValue()) {
      const prefix = remaining[0].value.slice(0, LOTID_PREFIX_LEN);
      const lotEl = getLotIdInput();
      if (lotEl) pasteValueToElement(lotEl, prefix);
      await sleep(TOAST_SETTLE_MS); // để toast (nếu có) của ô lot id qua hẳn rồi mới dán mã
    }

    // So sánh 11 ký tự đầu của từng mã với nội dung hiện tại của ô "Tem bản vẽ":
    // trùng thì dán, không trùng thì bỏ qua (chờ ô đó đổi sang đúng lot id).
    const lotVal = getLotIdValue();
    if (!lotVal) {
      flashPanel('#f44336', `Ô "${LOTID_LABEL_TEXT}" đang trống, không dán được`);
      return 'stop';
    }
    const currentPrefix = lotVal.slice(0, LOTID_PREFIX_LEN);
    const item = remaining.find((c) => c.value.slice(0, LOTID_PREFIX_LEN) === currentPrefix);
    if (!item) {
      flashPanel('#ff9800', `Không có mã nào khớp 11 ký tự đầu với "${LOTID_LABEL_TEXT}", đã bỏ qua`);
      return 'stop';
    }

    const errBefore = errorCount;
    const ok = await pasteAndConfirm(item.value);
    if (!ok) {
      if (skip) skip.add(item);
      flashPanel('#f44336', `Lỗi${errorCount > errBefore ? ' "' + lastErrorText + '"' : ''}, bỏ qua: "${item.value}" KHÔNG báo thành công (${codes.filter((c) => c.pasted).length}/${codes.length})`);
      return 'fail';
    }
    item.pasted = true;
    save();
    touchActivity();
    renderList();
    return 'ok';
  }

  let autoRunning = false;
  async function startAuto() {
    const t = getTargetEl();
    if (!t || t !== getPasteInput()) {
      flashPanel('#f44336', `Hãy click vào ô "${PASTE_LABEL_TEXT}" trước rồi bấm lại!`);
      return;
    }
    if (autoRunning) return;
    autoRunning = true;
    updateAutoBtn(true);
    const skip = new Set();
    while (autoRunning) {
      const r = await pasteNext(skip);
      if (r === 'stop') break;
      await sleep(DELAY_MS);
    }
    const total = codes.length;
    const okCount = codes.filter((c) => c.pasted).length;
    stopAuto();
    if (total > 0 && okCount === total) {
      codes = [];
      save();
      renderList();
      flashPanel('#4caf50', `Đã dán xong ${total}/${total} & tự xóa danh sách (Phần 1)`);
    } else if (skip.size > 0) {
      flashPanel('#ff9800', `Xong ${okCount}/${total}, lỗi ${skip.size} mã (còn giữ trong danh sách, bấm Dán để thử lại)`);
    }
  }
  function stopAuto() {
    autoRunning = false;
    updateAutoBtn(false);
  }
  function toggleAuto() {
    if (autoRunning) stopAuto();
    else startAuto();
  }

  // Phím tắt dán từng mã một (luôn thao tác trên Phần 1, giữ nguyên như cũ)
  document.addEventListener('keydown', (e) => {
    if (e.key === settings.hotkey) {
      e.preventDefault();
      pasteNext(null);
    }
  });

  // ---------- Tự xóa toàn bộ Phần 1 nếu để quá 1 tiếng không hoạt động (giữ như cũ) ----------
  setInterval(() => {
    if (codes.length > 0 && Date.now() - lastActivity > ONE_HOUR_MS) {
      codes = [];
      save();
      touchActivity();
      renderList();
      flashPanel('#ff9800', 'Quá 1 tiếng không dán, đã tự xóa danh sách (Phần 1)');
    }
  }, 60 * 1000);

  // ---------- Phần 2 (Backup): tự xóa TỪNG mã khi mã đó đủ 1 tiếng, mã chưa đủ vẫn giữ lại ----------
  setInterval(() => {
    const before = backupCodes.length;
    backupCodes = backupCodes.filter((c) => Date.now() - c.ts < ONE_HOUR_MS);
    if (backupCodes.length !== before) {
      save();
      renderBackup();
    }
  }, BACKUP_SWEEP_MS);

  // Đọc nội dung hiện tại của ô "Tem bản vẽ" (lot id) để lọc mã khớp trước khi dán tự động Backup
  function getLotIdValue() {
    const el = getLotIdInput();
    if (!el) return '';
    const raw = el.isContentEditable ? el.innerText : el.value || '';
    return raw.trim();
  }

  // ---------- Dán tự động cho Backup: KHÔNG đụng ô "Tem bản vẽ", dán xong KHÔNG xóa ----------
  // Chỉ dán những mã có 11 ký tự đầu trùng với nội dung hiện tại của ô "Tem bản vẽ".
  // Nếu ô đó đang trống thì không dán mã nào cả.
  // Mỗi lần bấm "Dán tự động" sẽ chạy lại từ đầu qua toàn bộ các mã khớp (kể cả mã
  // đã từng xanh trước đó), dán tới đâu xanh tới đó theo đúng thứ tự đã quét.
  let backupAutoQueue = [];
  let backupAutoQueueIndex = 0; // vị trí đang xử lý trong hàng đợi
  let backupAutoOk = 0; // số mã dán THÀNH CÔNG
  let backupAutoFail = 0; // số mã lỗi (bị bỏ qua)

  async function pasteNextBackup() {
    const target = getTargetEl();
    if (!target) {
      flashPanel('#f44336', `Hãy click vào ô "${PASTE_LABEL_TEXT}" trước!`);
      return 'stop';
    }
    if (target !== getPasteInput()) {
      flashPanel('#f44336', `Chỉ được dán vào ô "${PASTE_LABEL_TEXT}"! Đang chọn ô khác.`);
      return 'stop';
    }
    if (backupAutoQueueIndex >= backupAutoQueue.length) {
      flashPanel('#4caf50', 'Backup: đã dán xong các mã khớp lot id');
      return 'stop';
    }
    const item = backupAutoQueue[backupAutoQueueIndex];
    const errBefore = errorCount;
    const ok = await pasteAndConfirm(item.value);
    if (!ok) {
      backupAutoFail++;
      backupAutoQueueIndex++;
      flashPanel('#f44336', `Backup lỗi${errorCount > errBefore ? ' "' + lastErrorText + '"' : ''}, bỏ qua: "${item.value}" KHÔNG báo thành công (${backupAutoOk}/${backupAutoQueue.length})`);
      updateBackupAutoBtn(true);
      return 'fail';
    }
    item.pasted = true;
    backupAutoOk++;
    backupAutoQueueIndex++;
    save();
    touchActivity();
    renderBackup();
    updateBackupAutoBtn(true);
    return 'ok';
  }

  let backupRunning = false;
  async function startBackupAuto() {
    const t = getTargetEl();
    if (!t || t !== getPasteInput()) {
      flashPanel('#f44336', `Hãy click vào ô "${PASTE_LABEL_TEXT}" trước rồi bấm lại!`);
      return;
    }
    const lotVal = getLotIdValue();
    if (!lotVal) {
      flashPanel('#f44336', `Ô "${LOTID_LABEL_TEXT}" đang trống, không dán được`);
      return;
    }
    const prefix = lotVal.slice(0, LOTID_PREFIX_LEN);
    const matches = backupCodes.filter((c) => c.value.slice(0, LOTID_PREFIX_LEN) === prefix);
    if (matches.length === 0) {
      flashPanel('#f44336', `Backup: không có mã nào khớp 11 ký tự đầu với "${LOTID_LABEL_TEXT}"`);
      return;
    }
    if (backupRunning) return;
    backupAutoQueue = matches;
    backupAutoQueueIndex = 0;
    backupAutoOk = 0;
    backupAutoFail = 0;
    backupRunning = true;
    updateBackupAutoBtn(true);
    while (backupRunning) {
      if (backupAutoQueueIndex >= backupAutoQueue.length) break;
      const r = await pasteNextBackup();
      if (r === 'stop') break;
      await sleep(DELAY_MS);
    }
    const done = backupAutoOk;
    const total = backupAutoQueue.length;
    const fail = backupAutoFail;
    stopBackupAuto();
    if (fail > 0) {
      flashPanel('#ff9800', `Backup: dán ${done}/${total}, lỗi ${fail} mã`);
    } else if (done === total && total > 0) {
      flashPanel('#4caf50', `Backup: đã dán xong ${done}/${total}`);
    }
  }
  function stopBackupAuto() {
    backupRunning = false;
    updateBackupAutoBtn(false);
    renderList();
  }
  function toggleBackupAuto() {
    if (backupRunning) stopBackupAuto();
    else startBackupAuto();
  }

  // ---------- UI ----------
  const panel = document.createElement('div');
  panel.style.cssText = `
    position: fixed; top: 8px; right: 8px; left: auto; bottom: auto; width: 280px;
    background: linear-gradient(180deg, #eaf5ff 0%, #dcedfb 100%);
    color: #1c3d5a; font: 13px/1.4 sans-serif;
    border: 1px solid #bcdcf5;
    border-radius: 12px; box-shadow: 0 4px 16px rgba(30,90,140,.25);
    z-index: 2147483647; padding: 8px; user-select: none;
    display: none;
  `;
  panel.innerHTML = `
    <style>
      #mx2-topbar button, #mx2-body button {
        background: #5aa9e6; color: #fff; border: none; border-radius: 6px;
        padding: 4px 6px; cursor: pointer; font: inherit;
      }
      #mx2-topbar button:hover, #mx2-body button:hover { background: #4791d1; }
      #mx2-topbar button:disabled { background: #a9cbe8; cursor: default; }
      #mx2-body input[type="number"], #mx2-body input[type="text"] {
        background: #fff; color: #1c3d5a; border: 1px solid #bcdcf5;
        border-radius: 5px; padding: 2px 4px;
      }
      #mx2-body input[type="checkbox"] { accent-color: #5aa9e6; }
      #mx2-min:hover { color: #4791d1; }
      .mx2-section-title { font-weight: bold; color: #1c6fb0; margin: 4px 0 4px; }
      .mx2-row { display:flex; justify-content:space-between; align-items:center; padding:2px 0; gap:4px; }
      .mx2-row-val { overflow:hidden; text-overflow:ellipsis; white-space:nowrap; flex:1; }
      .mx2-mini-btn {
        background:#5aa9e6; color:#fff; border:none; border-radius:5px;
        padding:1px 6px; cursor:pointer; font:11px/1.4 sans-serif; flex-shrink:0;
      }
      .mx2-mini-btn:hover { background:#4791d1; }
      .mx2-remain { color:#888; font-size:11px; flex-shrink:0; min-width:34px; text-align:right; }
      .mx2-del { cursor:pointer; color:#f44336; flex-shrink:0; }
    </style>
    <div id="mx2-topbar" style="cursor:move; display:flex; align-items:center; gap:6px;">
      <span style="font-size:10px; font-weight:bold; color:#fff; background:#1c6fb0; border-radius:4px; padding:0 4px;">V2</span>
      <span id="mx2-count" style="font-weight:bold; min-width:16px; text-align:center; color:#1c6fb0;">0</span>
      <button id="mx2-auto-btn" style="flex:1; padding:2px 4px;">▶ Dán</button>
      <span id="mx2-min" style="cursor:pointer; padding:0 4px; font-weight:bold; color:#1c6fb0;">+</span>
    </div>
    <div id="mx2-body" style="display:none; margin-top:8px;">
      <div id="mx2-status" style="color:#3d6f96; margin-bottom:6px;">Sẵn sàng.</div>

      <div class="mx2-section-title">① Danh sách dán (tự xóa sau khi dán hết)</div>
      <div style="max-height:110px; overflow-y:auto; border:1px solid #bcdcf5; background:#f4faff; border-radius:6px; padding:4px; margin-bottom:6px;" id="mx2-list"></div>
      <div style="display:flex; gap:6px; margin-bottom:6px;">
        <button id="mx2-clear" style="flex:1;">Xóa hết Phần 1</button>
      </div>
      <div style="color:#8a6d3b; font-size:11px; margin-bottom:10px;">Chỉ tự điền lot id vào ô "${LOTID_LABEL_TEXT}" khi ô đó đang trống. Chỉ dán mã có 11 ký tự đầu trùng với ô "${LOTID_LABEL_TEXT}", mã không khớp sẽ tạm bỏ qua.</div>

      <div class="mx2-section-title">② Backup (mỗi mã tự xóa sau 1 giờ)</div>
      <div style="max-height:130px; overflow-y:auto; border:1px solid #bcdcf5; background:#fff8ee; border-radius:6px; padding:4px; margin-bottom:6px;" id="mx2-backup-list"></div>
      <div style="display:flex; gap:6px; margin-bottom:6px;">
        <button id="mx2-backup-auto-btn" style="flex:1;">▶ Dán tự động</button>
        <button id="mx2-backup-clear" style="flex:1;">Xóa hết</button>
      </div>
      <div style="color:#8a6d3b; font-size:11px; margin-bottom:6px;">Dán tự động ở Backup chỉ dán mã có 11 ký tự đầu trùng với ô "${LOTID_LABEL_TEXT}" (nếu ô đó trống sẽ không dán). Dán xong KHÔNG xóa, chỉ tự mất sau đúng 1h kể từ lúc quét.</div>

      <div style="color:#3d6f96;">Chỉ dán được khi đang chọn ô "${PASTE_LABEL_TEXT}". Phím tắt dán 1 mã (Phần 1): <b id="mx2-hotkey-label"></b></div>
    </div>
  `;
  document.documentElement.appendChild(panel);

  const $ = (sel) => panel.querySelector(sel);
  $('#mx2-hotkey-label').textContent = settings.hotkey;

  $('#mx2-clear').addEventListener('click', () => {
    if (!confirm('Xóa toàn bộ danh sách Phần 1 (danh sách dán)?')) return;
    codes = [];
    save();
    touchActivity();
    renderList();
  });
  $('#mx2-backup-clear').addEventListener('click', () => {
    if (!confirm('Xóa toàn bộ Backup (Phần 2)? Các mã đang chờ hết 1h sẽ mất luôn.')) return;
    backupCodes = [];
    save();
    renderBackup();
  });
  $('#mx2-auto-btn').addEventListener('click', toggleAuto);
  $('#mx2-backup-auto-btn').addEventListener('click', toggleBackupAuto);

  let minimized = true;
  function applyMinimized() {
    $('#mx2-body').style.display = minimized ? 'none' : 'block';
    $('#mx2-min').textContent = minimized ? '+' : '–';
    panel.style.width = minimized ? '150px' : '300px';
  }
  $('#mx2-min').addEventListener('click', () => {
    minimized = !minimized;
    applyMinimized();
  });

  // Kéo thả panel
  (function makeDraggable() {
    const header = $('#mx2-topbar');
    let dragging = false, offX = 0, offY = 0;
    header.addEventListener('mousedown', (e) => {
      if (e.target.id === 'mx2-auto-btn' || e.target.id === 'mx2-min') return;
      dragging = true;
      offX = e.clientX - panel.getBoundingClientRect().left;
      offY = e.clientY - panel.getBoundingClientRect().top;
    });
    document.addEventListener('mousemove', (e) => {
      if (!dragging) return;
      panel.style.left = e.clientX - offX + 'px';
      panel.style.top = e.clientY - offY + 'px';
      panel.style.right = 'auto';
      panel.style.bottom = 'auto';
    });
    document.addEventListener('mouseup', () => (dragging = false));
  })();

  function updateAutoBtn(running) {
    const done = codes.filter((c) => c.pasted).length;
    $('#mx2-auto-btn').textContent = running ? `⏳ ${done}/${codes.length}` : '▶ Dán';
  }
  function updateBackupAutoBtn(running) {
    const txt = running ? `⏳ ${backupAutoOk}/${backupAutoQueue.length}` : '▶ Dán tự động';
    $('#mx2-backup-auto-btn').textContent = txt;
    if (running) $('#mx2-count').textContent = `${backupAutoOk}/${backupAutoQueue.length}`;
  }

  // ---------- Render Phần 1 ----------
  function renderList() {
    const list = $('#mx2-list');
    if (codes.length === 0) {
      list.innerHTML = '<i style="color:#777;">Chưa có mã nào</i>';
    } else {
      list.innerHTML = codes
        .map(
          (c, i) =>
            `<div class="mx2-row" style="${c.pasted ? 'color:#4caf50;' : ''}">
              <span class="mx2-row-val">${i + 1}. ${escapeHtml(c.value)} ${c.pasted ? '✓' : ''}</span>
              <span class="mx2-del" data-del="${i}">✕</span>
            </div>`
        )
        .join('');
      list.querySelectorAll('[data-del]').forEach((el) => {
        el.addEventListener('click', () => {
          codes.splice(parseInt(el.getAttribute('data-del'), 10), 1);
          save();
          renderList();
        });
      });
    }
    const remain = codes.filter((c) => !c.pasted).length;
    const pastedCount = codes.length - remain;
    $('#mx2-status').textContent = `Phần 1 - Tổng: ${codes.length} | Chưa dán: ${remain}`;
    if (!backupRunning) {
      $('#mx2-count').textContent = pastedCount > 0 ? `${pastedCount}/${codes.length}` : `${codes.length}`;
    }
    updateAutoBtn(autoRunning);
  }

  // ---------- Render Phần 2 (Backup) ----------
  function formatRemain(ms) {
    if (ms <= 0) return '0p';
    const totalSec = Math.ceil(ms / 1000);
    const m = Math.floor(totalSec / 60);
    const s = totalSec % 60;
    return `${m}p${s.toString().padStart(2, '0')}`;
  }

  function renderBackup() {
    const list = $('#mx2-backup-list');
    if (backupCodes.length === 0) {
      list.innerHTML = '<i style="color:#777;">Chưa có mã nào</i>';
      return;
    }
    // mới nhất lên trên cho dễ tìm mã vừa dán nhầm
    const rows = backupCodes
      .map((c, i) => ({ c, i }))
      .sort((a, b) => b.c.ts - a.c.ts);

    list.innerHTML = rows
      .map(
        ({ c, i }) =>
          `<div class="mx2-row" style="${c.pasted ? 'color:#4caf50;' : ''}">
            <span class="mx2-row-val">${escapeHtml(c.value)} ${c.pasted ? '✓' : ''}</span>
            <span class="mx2-remain" data-ts="${c.ts}"></span>
            <span class="mx2-del" data-bdel="${i}">✕</span>
          </div>`
      )
      .join('');

    list.querySelectorAll('[data-bdel]').forEach((el) => {
      el.addEventListener('click', () => {
        const idx = parseInt(el.getAttribute('data-bdel'), 10);
        backupCodes.splice(idx, 1);
        save();
        renderBackup();
      });
    });

    updateBackupCountdowns();
  }

  // Cập nhật đồng hồ đếm ngược của backup mỗi giây mà không phải render lại toàn bộ list
  function updateBackupCountdowns() {
    const spans = $('#mx2-backup-list').querySelectorAll('.mx2-remain');
    spans.forEach((sp) => {
      const ts = parseInt(sp.getAttribute('data-ts'), 10);
      const remain = ONE_HOUR_MS - (Date.now() - ts);
      sp.textContent = formatRemain(remain);
    });
  }
  setInterval(updateBackupCountdowns, COUNTDOWN_TICK_MS);

  function escapeHtml(s) {
    return s.replace(/[&<>"']/g, (m) => ({
      '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;',
    }[m]));
  }

  let flashTimer = null;
  function flashPanel(color, msg) {
    const status = $('#mx2-status');
    status.style.color = color;
    status.textContent = msg;
    clearTimeout(flashTimer);
    flashTimer = setTimeout(() => {
      status.style.color = '#3d6f96';
      renderList();
    }, 1200);
  }

  renderList();
  renderBackup();
  updateTargetLabel();
  applyMinimized();

  // Web dạng SPA (chuyển trang không load lại toàn bộ) đôi khi tự dọn dẹp
  // các phần tử lạ không do nó tạo ra -> kiểm tra định kỳ, tự chèn lại panel nếu bị mất.
  setInterval(() => {
    if (!document.documentElement.contains(panel)) {
      document.documentElement.appendChild(panel);
    }
  }, 1000);
})();
