const TARGET_PREFIX = "http://192.168.9.102/";

// Hàm xử lý kiểm tra và chuyển tab
function focusOrOpenTab(newTabId = null) {
  chrome.tabs.query({}, (tabs) => {
    // Tìm các tab có địa chỉ bắt đầu bằng http://192.168.9.102/
    const matchingTabs = tabs.filter(
      (tab) => tab.url && tab.url.startsWith(TARGET_PREFIX)
    );

    // Nếu chưa có tab cũ nào (chỉ có tối đa 1 tab vừa mở ra từ shortcut):
    if (matchingTabs.length === 0) {
      chrome.tabs.create({ url: TARGET_PREFIX });
      return;
    }

    if (matchingTabs.length === 1 && !newTabId) {
      // Bấm icon extension khi chưa có tab nào
      const singleTab = matchingTabs[0];
      chrome.windows.update(singleTab.windowId, { focused: true }, () => {
        chrome.tabs.update(singleTab.id, { active: true });
      });
      return;
    }

    // Nếu đã có tab cũ và vừa có thêm tab mới từ Shortcut Desktop mở ra:
    if (matchingTabs.length > 1 || (matchingTabs.length === 1 && newTabId)) {
      // Tìm tab cũ đã mở từ trước (không phải newTabId)
      const existingTab = matchingTabs.find((tab) => tab.id !== newTabId);

      if (existingTab) {
        // 1. Chuyển sang tab cũ
        chrome.windows.update(existingTab.windowId, { focused: true }, () => {
          chrome.tabs.update(existingTab.id, { active: true });
        });

        // 2. Đóng tab thừa vừa bật lên từ Desktop Shortcut
        if (newTabId) {
          chrome.tabs.remove(newTabId);
        }
      }
    }
  });
}

// 1. Xử lý khi click trực tiếp vào Icon Extension trên thanh công cụ
chrome.action.onClicked.addListener(() => {
  focusOrOpenTab();
});

// 2. Xử lý khi mở từ Shortcut Desktop (Lắng nghe sự kiện duyệt web)
chrome.webNavigation.onBeforeNavigate.addListener((details) => {
  if (details.frameId === 0 && details.url.startsWith(TARGET_PREFIX)) {
    focusOrOpenTab(details.tabId);
  }
});